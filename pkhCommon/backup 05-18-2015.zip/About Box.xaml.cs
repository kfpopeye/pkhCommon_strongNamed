﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Reflection;
using System.Net;
using System.IO;
using System.Xml;
using License;

namespace pkhCommon.Windows
{
    /// <summary>
    /// Interaction logic for About_Box.xaml
    /// </summary>
    public partial class About_Box : Window
    {
        private string AppVersion = null;
        private bool IsReVVed = false;

        public About_Box()
        {
            InitializeComponent();

            this.Title = String.Format("About {0}", AssemblyTitle);
            this.labelProductName.Text = AssemblyProduct;
            this.labelVersion.Text = String.Format("Version {0}.{1}.{2}.{3}", MajorVersion, MinorVersion, Build, Revision);
            this.labelCopyright.Text = AssemblyCopyright;
            this.labelCompanyName.Text = AssemblyCompany;
            AppVersion = Build;
#if !DEBUG
            this.textBoxDescription.Text = getDescription();
#else
            this.textBoxDescription.Text = "Registration and assembly information not available in debug mode.Registration and assembly information not available in debug mode.Registration and assembly information not available in debug mode.Registration and assembly information not available in debug mode.Registration and assembly information not available in debug mode.Registration and assembly information not available in debug mode.";
#endif
        }

        /// <summary>
        /// For use with ReVVed only
        /// </summary>
        /// <param name="app_version">Release version of ReVVed</param>
        public About_Box(string app_version)
        {
            InitializeComponent();

            this.Title = String.Format("About {0}", AssemblyProduct);
            this.labelProductName.Text = AssemblyProduct;
            this.labelVersion.Text = String.Format("Version {0}.{1}.{2}.{3}", MajorVersion, MinorVersion, Build, Revision);
            this.labelCopyright.Text = AssemblyCopyright;
            this.labelCompanyName.Text = AssemblyCompany;

            AppVersion = app_version;
            okButton.Visibility = System.Windows.Visibility.Collapsed;
            IsReVVed = true;
#if !DEBUG
            this.textBoxDescription.Text = checkedForUpdates();
#else
            this.textBoxDescription.Text = "Assembly information not available in debug mode.";
#endif
        }

        private string getDescription()
        {

            System.Text.StringBuilder desc = new System.Text.StringBuilder();
            desc.AppendLine(checkedForUpdates());
            desc.AppendLine("-----------");

            if (License.Status.Licensed)
            {
                desc.AppendLine("Registered to: " + License.Status.KeyValueList["RegName"].ToString());
                desc.AppendLine("Email: " + License.Status.KeyValueList["Email"].ToString());
                //desc.AppendLine("Password: " + License.Status.KeyValueList["P$$w0rd"].ToString());
                okButton.Content = "Transer License";
                okButton.Click -= okButton_Register;
                okButton.Click += okButton_Deregister;
            }
            else
            {
                desc.AppendLine("This version of " + AssemblyTitle + " is currently unregistered.");
                desc.AppendLine("You have " + (License.Status.Evaluation_Time - License.Status.Evaluation_Time_Current).ToString() + " days left to register");
                desc.AppendLine("before the program stops functioning.");
            }

            //desc.AppendLine("Hardware ID: " + License.Status.HardwareID.ToString());

            return desc.ToString();
        }

        private string checkedForUpdates()
        {
            HttpWebRequest myHttpWebRequest = (HttpWebRequest)WebRequest.Create("http://www.pkhlineworks.ca/softwareversions.xml");
            HttpWebResponse myHttpWebResponse = (HttpWebResponse)myHttpWebRequest.GetResponse();
            // Gets the stream associated with the response.
            Stream receiveStream = myHttpWebResponse.GetResponseStream();

            //Major-Revit version   Minor-App version   MajorRevision-App update version    MinorRevision-not used
            //AssemblyTitle must be as it appears in softwareversions.xml
            XmlReader Xread = XmlReader.Create(receiveStream);
            if (IsReVVed)
                Xread.ReadToFollowing(AssemblyTitle + MajorVersion);
            else
                Xread.ReadToFollowing(AssemblyTitle + MajorVersion + "_V" + MinorVersion);
            int ver = Xread.ReadElementContentAsInt();
            int thisVer = Convert.ToInt32(AppVersion);

            // Releases the resources of the response.
            myHttpWebResponse.Close();
            // Releases the resources of the Stream.
            receiveStream.Close();

            if (ver > thisVer)
                return ("A newer version of " + AssemblyTitle + " is available." + " Version " + ver.ToString() + " is available at www.pkhlineworks.ca.");
            else
                return "Your product is up to date.";
        }

        #region Assembly Attribute Accessors

        public string AssemblyTitle
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyTitleAttribute), false);
                if (attributes.Length > 0)
                {
                    AssemblyTitleAttribute titleAttribute = (AssemblyTitleAttribute)attributes[0];
                    if (titleAttribute.Title != "")
                    {
                        return titleAttribute.Title;
                    }
                }
                return System.IO.Path.GetFileNameWithoutExtension(Assembly.GetExecutingAssembly().CodeBase);
            }
        }

        public string AssemblyVersion
        {
            get
            {
                return Assembly.GetExecutingAssembly().GetName().Version.ToString();
            }
        }

        public string MajorVersion
        {
            get
            {
                return Assembly.GetExecutingAssembly().GetName().Version.Major.ToString();
            }
        }

        public string MinorVersion
        {
            get
            {
                return Assembly.GetExecutingAssembly().GetName().Version.Minor.ToString();
            }
        }

        public string Build
        {
            get
            {
                return Assembly.GetExecutingAssembly().GetName().Version.Build.ToString();
            }
        }

        public string Revision
        {
            get
            {
                return Assembly.GetExecutingAssembly().GetName().Version.Revision.ToString();
            }
        }

        public string AssemblyDescription
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyDescriptionAttribute), false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyDescriptionAttribute)attributes[0]).Description;
            }
        }

        public string AssemblyProduct
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyProductAttribute), false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyProductAttribute)attributes[0]).Product;
            }
        }

        public string AssemblyCopyright
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyCopyrightAttribute), false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyCopyrightAttribute)attributes[0]).Copyright;
            }
        }

        public string AssemblyCompany
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyCompanyAttribute), false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyCompanyAttribute)attributes[0]).Company;
            }
        }
        #endregion

        private void okButton_Deregister(object sender, RoutedEventArgs e)
        {
            pkhCommon.Windows.Input_Box wpfIb = new pkhCommon.Windows.Input_Box(
                AssemblyTitle, 
                "Password required!", 
                "You are about to deactivate your license on this machine. An internet connection is required to complete this. If this is what you want enter your password below and click OK.");
            wpfIb.IsPassword = true;
            wpfIb.Owner = this;
            wpfIb.ShowDialog();

            if ((bool)wpfIb.DialogResult)
            {
                if (License.Status.KeyValueList["P$$w0rd"].ToString() == wpfIb.UserInput)
                {
                    Email.TransferSoftware(AssemblyProduct, AssemblyVersion);
                }
                else
                    MessageBox.Show("Incorrect password.");
            }
        }

        private void okButton_Register(object sender, RoutedEventArgs e)
        {
            Email.RegisterSoftware(AssemblyProduct, AssemblyVersion);
        }
    }
}
