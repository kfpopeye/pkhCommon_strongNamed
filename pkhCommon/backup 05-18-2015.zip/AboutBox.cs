﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using System.Net;
using System.IO;
using System.Xml;
using License;

namespace pkhCommon.Windows
{
    partial class AboutBox : Form
    {
        public AboutBox()
        {
            InitializeComponent();
            this.Text = String.Format("About {0}", AssemblyTitle);
            this.labelProductName.Text = AssemblyProduct;
            this.labelVersion.Text = String.Format("Version {0}", AssemblyVersion);
            this.labelCopyright.Text = AssemblyCopyright;
            this.labelCompanyName.Text = AssemblyCompany;
            this.textBoxDescription.Text = getDescription();
        }

        private string getDescription()
        {

            System.Text.StringBuilder desc = new System.Text.StringBuilder();
#if (DEBUG == false)
            desc.AppendLine(checkedForUpdates());
            desc.AppendLine("-----------");

            if (License.Status.Licensed)
            {
                desc.AppendLine("Registered to: " + License.Status.KeyValueList["RegName"].ToString());
                desc.AppendLine("Email: " + License.Status.KeyValueList["Email"].ToString());
                //desc.AppendLine("Password: " + License.Status.KeyValueList["P$$w0rd"].ToString());
                okButton.Text = "Transer License";
                okButton.Click -= okButton_Register;
                okButton.Click += okButton_Deregister;
            }
            else
            {
                desc.AppendLine("This version of " + Constants.GROUP_NAME + " is currently unregistered.");
                desc.AppendLine("You have " + (License.Status.Evaluation_Time - License.Status.Evaluation_Time_Current).ToString() + " days left to register");
                desc.AppendLine("before the program stops functioning.");
            }

            //desc.AppendLine("Hardware ID: " + License.Status.HardwareID.ToString());
#else
            desc.AppendLine("No license information for " + Constants.GROUP_NAME + " available in debug mode.");
#endif

            return desc.ToString();
        }

        private string checkedForUpdates()
        {
            try
            {
                HttpWebRequest myHttpWebRequest = (HttpWebRequest)WebRequest.Create("http://www.pkhlineworks.ca/softwareversions.xml");
                HttpWebResponse myHttpWebResponse = (HttpWebResponse)myHttpWebRequest.GetResponse();
                // Gets the stream associated with the response.
                Stream receiveStream = myHttpWebResponse.GetResponseStream();

                //Major-Revit version   Minor-App version   MajorRevision-App update version    MinorRevision-not used
                XmlReader Xread = XmlReader.Create(receiveStream);
                Xread.ReadToFollowing(Constants.GROUP_NAME + Assembly.GetExecutingAssembly().GetName().Version.Major.ToString() + "_V" + Assembly.GetExecutingAssembly().GetName().Version.Minor.ToString());
                int ver = Xread.ReadElementContentAsInt();
                int thisVer = Convert.ToInt32(Assembly.GetExecutingAssembly().GetName().Version.Build);

                // Releases the resources of the response.
                myHttpWebResponse.Close();
                // Releases the resources of the Stream.
                receiveStream.Close();

                if (ver > thisVer)
                {
                    return ("A newer version of " + Constants.GROUP_NAME + " is available." + " Version " + ver.ToString() + " is available at www.pkhlineworks.ca");
                }
                else
                    return "Your product is up to date.";
            }
            catch (Exception err)
            {
                Autodesk.Revit.UI.TaskDialog td = new Autodesk.Revit.UI.TaskDialog("CheckVersion Error");
                td.MainInstruction = Constants.GROUP_NAME + " has encountered a non-critical error.";
                td.MainContent = "Please use the link below to send a bug report to the developer. You will be able to see the bug report before you send it.";
                td.ExpandedContent = err.ToString();
                td.AddCommandLink(Autodesk.Revit.UI.TaskDialogCommandLinkId.CommandLink1, "Send bug report.");
                td.MainIcon = Autodesk.Revit.UI.TaskDialogIcon.TaskDialogIconWarning;
                Autodesk.Revit.UI.TaskDialogResult tdr = td.Show();

                if (tdr == Autodesk.Revit.UI.TaskDialogResult.CommandLink1)
                {
                    Email.SendErrorMessage(
                         Constants.GROUP_NAME,
                        "Major Version = " + Assembly.GetExecutingAssembly().GetName().Version.Major.ToString() + " - " + "Build = " + Assembly.GetExecutingAssembly().GetName().Version.Build.ToString(),
                        err,
                        this.GetType().Assembly.GetName()
                        );
                }

                return "An error occured while checking if your product was up to date. Please try again later.";
            }
        }

        #region Assembly Attribute Accessors

        public string AssemblyTitle
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyTitleAttribute), false);
                if (attributes.Length > 0)
                {
                    AssemblyTitleAttribute titleAttribute = (AssemblyTitleAttribute)attributes[0];
                    if (titleAttribute.Title != "")
                    {
                        return titleAttribute.Title;
                    }
                }
                return System.IO.Path.GetFileNameWithoutExtension(Assembly.GetExecutingAssembly().CodeBase);
            }
        }

        public string AssemblyVersion
        {
            get
            {
                return Assembly.GetExecutingAssembly().GetName().Version.ToString();
            }
        }

        public string AssemblyDescription
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyDescriptionAttribute), false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyDescriptionAttribute)attributes[0]).Description;
            }
        }

        public string AssemblyProduct
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyProductAttribute), false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyProductAttribute)attributes[0]).Product;
            }
        }

        public string AssemblyCopyright
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyCopyrightAttribute), false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyCopyrightAttribute)attributes[0]).Copyright;
            }
        }

        public string AssemblyCompany
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyCompanyAttribute), false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyCompanyAttribute)attributes[0]).Company;
            }
        }
        #endregion

        private void okButton_Register(object sender, EventArgs e)
        {
            Email.RegisterSoftware(AssemblyProduct, AssemblyVersion);
        }

        private void okButton_Deregister(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("You are about to deactivate your license on this machine. An internet connection is required to complete this. Do you want to continue?", "Warning!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (res == System.Windows.Forms.DialogResult.No)
                return;

            InputBox ib = new InputBox("Enter your password", "Transfer Confirmation");
            ib.ShowDialog();
            if (ib.DialogResult == System.Windows.Forms.DialogResult.OK)
            {
                if (License.Status.KeyValueList["P$$w0rd"].ToString() == ib.Input)
                {
                    Email.TransferSoftware(AssemblyProduct, AssemblyVersion);
                }
                else
                    MessageBox.Show("Incorrect password.");
            }
        }
    }
}